1.	Start the Redis Server (By default it will start on port 6379) by executing redis-server.exe (Redis is also available in zip solution)
2.	Start the spring boot service
3.	Run the unit test
4.	You can also use postmen to connect to diff endpoints and do the operation on cache.
Sample JSON Payload:
{
    "id":"AAPL_TW",
    "instrumentId":"APPL",
    "provider":"TW",
    "price":5009
}
