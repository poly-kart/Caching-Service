package com.mizuho.assignment.cache.service;

import com.mizuho.assignment.cache.entity.PricingData;
import com.mizuho.assignment.cache.message.Publisher;
import com.mizuho.assignment.cache.repository.PriceDataRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.listener.ChannelTopic;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PriceCacheServiceImpl implements PriceCacheService {

    private static final Logger LOGGER = LoggerFactory.getLogger(PriceCacheServiceImpl.class);

    @Autowired
    PriceDataRepository priceDataRepository;

    @Autowired
    ChannelTopic cachedPriceTopic;

    @Autowired
    private Publisher publisher;

    public PricingData save(PricingData pricingData) {

        PricingData saveData = priceDataRepository.save(pricingData);
        LOGGER.info("Price data saved for : " + pricingData.getId() + " price = " + pricingData.getPrice());
        publisher.publish(cachedPriceTopic, pricingData);
        LOGGER.info("Published price data for : " + pricingData.getId() + " on topic : " + cachedPriceTopic.getTopic());
        return saveData;
    }

    public List<PricingData> findByInstrumentId(String instrumentId) {
        List<PricingData> pricingData = priceDataRepository.findByInstrumentId(instrumentId);
        LOGGER.info("[" + pricingData.size() + "] Price data found for instrumentId : " + instrumentId);
        return pricingData;
    }

    public List<PricingData> findByProvider(String provider) {
        List<PricingData> pricingData = priceDataRepository.findByProvider(provider);
        LOGGER.info("[" + pricingData.size() + "] Price data found for provider : " + provider);
        return pricingData;
    }
}
