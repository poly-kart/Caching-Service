package com.mizuho.assignment.cache.controller;

import com.mizuho.assignment.cache.entity.PricingData;
import com.mizuho.assignment.cache.message.Publisher;
import com.mizuho.assignment.cache.service.PriceCacheService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.listener.ChannelTopic;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/pricing-data-cache")
public class PriceCacheController {

    @Autowired
    ChannelTopic vendorPriceTopic;
    @Autowired
    ChannelTopic cachedPriceTopic;
    @Autowired
    private PriceCacheService priceCacheService;
    @Autowired
    private Publisher publisher;

    @PostMapping("/save")
    public PricingData save(@RequestBody PricingData pricingData) {
        return priceCacheService.save(pricingData);
    }

    @GetMapping("/instrument/{instrumentId}")
    public List<PricingData> findByInstrumentId(@PathVariable String instrumentId) {
        return priceCacheService.findByInstrumentId(instrumentId);
    }


    @GetMapping("/provider/{provider}")
    public List<PricingData> findByProvider(@PathVariable String provider) {
        return priceCacheService.findByProvider(provider);
    }

    @PostMapping("/publish-vendor")
    public String publishOnVendorTopic(@RequestBody PricingData pricingData) {
        return publisher.publish(vendorPriceTopic, pricingData);
    }

    @PostMapping("/publish-cache")
    public String publishOnCacheTopic(@RequestBody PricingData pricingData) {
        return publisher.publish(cachedPriceTopic, pricingData);
    }


}
