package com.mizuho.assignment.cache.service;

import com.mizuho.assignment.cache.entity.PricingData;

import java.util.List;

public interface PriceCacheService {

    PricingData save(PricingData pricingData);

    List<PricingData> findByInstrumentId(String instrumentId);

    List<PricingData> findByProvider(String provider);
}
