package com.mizuho.assignment.cache.message;

import com.mizuho.assignment.cache.entity.PricingData;
import com.mizuho.assignment.cache.service.PriceCacheService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.connection.Message;
import org.springframework.data.redis.connection.MessageListener;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

@Component
public class Receiver implements MessageListener {

    private static final Logger LOGGER = LoggerFactory.getLogger(Receiver.class);

    @Autowired
    private PriceCacheService priceCacheService;

    @Autowired
    private RedisTemplate template;

    @Override
    public void onMessage(Message message, byte[] bytes) {
        PricingData pricingData = (PricingData) template.getDefaultSerializer().deserialize(message.getBody());
        LOGGER.info("Received price data for : " + pricingData.getId());
        priceCacheService.save(pricingData);
    }

}
