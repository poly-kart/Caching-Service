package com.mizuho.assignment.cache.repository;

import com.mizuho.assignment.cache.entity.PricingData;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PriceDataRepository extends CrudRepository<PricingData, String> {

    List<PricingData> findByInstrumentId(String instrumentId);

    List<PricingData> findByProvider(String provider);
}
