package com.mizuho.assignment.cache.message;

import com.mizuho.assignment.cache.entity.PricingData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.listener.ChannelTopic;
import org.springframework.stereotype.Component;

@Component
public class Publisher {
    @Autowired
    private RedisTemplate template;

    public String publish(ChannelTopic topic, PricingData pricingData) {

        template.convertAndSend(topic.getTopic(), pricingData);
        return "Event Published";
    }


}
