package com.mizuho.assignment.cache.service;

import com.mizuho.assignment.cache.entity.PricingData;
import org.junit.Assert;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.data.redis.DataRedisTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

@ComponentScan(basePackages = {"com.mizuho.assignment.cache.*"})
@RunWith(SpringRunner.class)
@DataRedisTest
class PriceCacheServiceTest {
    @Autowired
    PriceCacheService service;

    @Test
    public void testSave() {
        PricingData pricingData = new PricingData();
        pricingData.setId("APPLTW");
        pricingData.setInstrumentId("APPL");
        pricingData.setProvider("TW");
        pricingData.setPrice(1000D);
        pricingData = service.save(pricingData);

        Assert.assertNotNull(pricingData);

        PricingData pricingData2 = new PricingData();
        pricingData2.setId("APPLBBG");
        pricingData2.setInstrumentId("APPL");
        pricingData2.setProvider("BBG");
        pricingData2.setPrice(1000D);
        pricingData2 = service.save(pricingData2);

        Assert.assertNotNull(pricingData2);
    }

    @Test
    public void testFindByInstrumentId() {
        List<PricingData> prices = service.findByInstrumentId("APPL");
        Assert.assertEquals(2, prices.size());
    }

    @Test
    public void testFindByProvider() {
        List<PricingData> prices = service.findByProvider("TW");
        Assert.assertEquals(1, prices.size());
    }

    @Test
    public void testExpiry() throws InterruptedException {
        Thread.sleep(61000);
        List<PricingData> prices = service.findByInstrumentId("APPL");
        Assert.assertEquals(0, prices.size());
    }
}